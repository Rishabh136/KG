package com.kgshop.data.entities

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(tableName = "employees")
data class Employee(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val employeeCode: String,
    val name: String,
    val phone: String,
    val password: String,
    val salaryType: SalaryType,
    val salaryAmount: Double,
    val joiningDate: String, // "yyyy-MM-dd"
    val isAdmin: Boolean = false,
    val isActive: Boolean = true
) : Parcelable

enum class SalaryType {
    MONTHLY, DAILY
}
