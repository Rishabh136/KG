package com.kgshop.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.kgshop.data.entities.Attendance
import com.kgshop.data.entities.AttendanceStatus
import com.kgshop.data.repository.KGShopRepository
import com.kgshop.utils.DateUtils
import kotlinx.coroutines.launch

class AttendanceViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = KGShopRepository(application)

    val operationResult = MutableLiveData<OperationResult>()
    val todayAttendance = MutableLiveData<Attendance?>()

    fun getPresentCountForDate(date: String = DateUtils.today()) =
        repository.getPresentCountForDate(date)

    fun getAttendanceForEmployee(employeeId: Long) =
        repository.getAttendanceForEmployee(employeeId)

    fun getMonthlyAttendance(employeeId: Long, month: String) =
        repository.getMonthlyAttendance(employeeId, month)

    fun getAllAttendanceForMonth(month: String) =
        repository.getAllAttendanceForMonth(month)

    fun getAttendanceByDate(date: String) =
        repository.getAttendanceByDate(date)

    fun loadTodayAttendance(employeeId: Long) {
        viewModelScope.launch {
            todayAttendance.value = repository.getTodayAttendance(employeeId)
        }
    }

    fun clockIn(employeeId: Long) {
        viewModelScope.launch {
            val result = repository.clockIn(employeeId)
            if (result.isSuccess) {
                todayAttendance.value = result.getOrNull()
                operationResult.value = OperationResult.Success("Clocked in successfully!")
            } else {
                operationResult.value = OperationResult.Error(
                    result.exceptionOrNull()?.message ?: "Clock-in failed"
                )
            }
        }
    }

    fun clockOut(attendance: Attendance) {
        viewModelScope.launch {
            val result = repository.clockOut(attendance.id)
            if (result.isSuccess) {
                todayAttendance.value = result.getOrNull()
                operationResult.value = OperationResult.Success("Clocked out successfully!")
            } else {
                operationResult.value = OperationResult.Error(
                    result.exceptionOrNull()?.message ?: "Clock-out failed"
                )
            }
        }
    }

    fun updateAttendance(attendance: Attendance) {
        viewModelScope.launch {
            repository.updateAttendance(attendance)
            operationResult.value = OperationResult.Success("Attendance updated")
        }
    }

    fun addManualAttendance(
        employeeId: Long,
        date: String,
        timeIn: String,
        timeOut: String,
        status: AttendanceStatus
    ) {
        viewModelScope.launch {
            val hours = if (timeIn.isNotBlank() && timeOut.isNotBlank())
                DateUtils.calculateHours(timeIn, timeOut) else 0.0
            val attendance = Attendance(
                employeeId = employeeId,
                date = date,
                timeIn = timeIn.ifBlank { null },
                timeOut = timeOut.ifBlank { null },
                totalHours = hours,
                status = status
            )
            repository.insertAttendance(attendance)
            operationResult.value = OperationResult.Success("Attendance saved")
        }
    }

    sealed class OperationResult {
        data class Success(val message: String) : OperationResult()
        data class Error(val message: String) : OperationResult()
    }
}
