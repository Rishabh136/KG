package com.kgshop.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.kgshop.data.dao.*
import com.kgshop.data.entities.*
import com.kgshop.utils.Converters
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import com.kgshop.utils.HashUtils

@Database(
    entities = [Employee::class, Attendance::class, Advance::class, Payroll::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class KGShopDatabase : RoomDatabase() {

    abstract fun employeeDao(): EmployeeDao
    abstract fun attendanceDao(): AttendanceDao
    abstract fun advanceDao(): AdvanceDao
    abstract fun payrollDao(): PayrollDao

    companion object {
        @Volatile
        private var INSTANCE: KGShopDatabase? = null

        fun getDatabase(context: Context): KGShopDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    KGShopDatabase::class.java,
                    "kgshop_database"
                )
                    .addCallback(DatabaseCallback())
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                // Insert default admin on first create
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        val adminPassword = HashUtils.sha256("admin123")
                        database.employeeDao().insert(
                            Employee(
                                employeeCode = "ADMIN",
                                name = "Admin",
                                phone = "0000000000",
                                password = adminPassword,
                                salaryType = SalaryType.MONTHLY,
                                salaryAmount = 0.0,
                                joiningDate = "2024-01-01",
                                isAdmin = true
                            )
                        )
                    }
                }
            }
        }
    }
}
