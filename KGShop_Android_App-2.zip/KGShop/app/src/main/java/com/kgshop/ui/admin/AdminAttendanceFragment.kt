package com.kgshop.ui.admin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.kgshop.data.entities.Attendance
import com.kgshop.data.entities.AttendanceStatus
import com.kgshop.databinding.FragmentAdminAttendanceBinding
import com.kgshop.ui.admin.adapters.AttendanceAdapter
import com.kgshop.utils.DateUtils
import com.kgshop.utils.showToast
import com.kgshop.viewmodel.AttendanceViewModel
import com.kgshop.viewmodel.EmployeeViewModel

class AdminAttendanceFragment : Fragment() {

    private var _binding: FragmentAdminAttendanceBinding? = null
    private val binding get() = _binding!!
    private val attendanceVM: AttendanceViewModel by viewModels()
    private val employeeVM: EmployeeViewModel by viewModels()
    private lateinit var adapter: AttendanceAdapter
    private var currentMonth = DateUtils.currentMonth()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAdminAttendanceBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        updateMonthDisplay()
        setupRecyclerView()
        loadAttendance()

        binding.btnPrevMonth.setOnClickListener {
            currentMonth = getPrevMonth(currentMonth)
            updateMonthDisplay()
            loadAttendance()
        }
        binding.btnNextMonth.setOnClickListener {
            currentMonth = getNextMonth(currentMonth)
            updateMonthDisplay()
            loadAttendance()
        }

        binding.fabAddAttendance.setOnClickListener {
            showAddAttendanceDialog()
        }

        attendanceVM.operationResult.observe(viewLifecycleOwner) {
            when (it) {
                is AttendanceViewModel.OperationResult.Success -> requireContext().showToast(it.message)
                is AttendanceViewModel.OperationResult.Error -> requireContext().showToast(it.message)
            }
        }
    }

    private fun setupRecyclerView() {
        adapter = AttendanceAdapter(showEmployeeName = true) { attendance ->
            showEditDialog(attendance)
        }
        binding.rvAttendance.layoutManager = LinearLayoutManager(requireContext())
        binding.rvAttendance.adapter = adapter
    }

    private fun loadAttendance() {
        attendanceVM.getAllAttendanceForMonth(currentMonth).observe(viewLifecycleOwner) { list ->
            adapter.submitList(list)
            binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun showEditDialog(attendance: Attendance) {
        EditAttendanceDialog(attendance) { updated ->
            attendanceVM.updateAttendance(updated)
        }.show(parentFragmentManager, "EditAttendance")
    }

    private fun showAddAttendanceDialog() {
        EditAttendanceDialog(null) { attendance ->
            attendanceVM.addManualAttendance(
                attendance.employeeId,
                attendance.date,
                attendance.timeIn ?: "",
                attendance.timeOut ?: "",
                attendance.status
            )
        }.show(parentFragmentManager, "AddAttendance")
    }

    private fun updateMonthDisplay() {
        binding.tvCurrentMonth.text = DateUtils.formatMonthForDisplay(currentMonth)
    }

    private fun getPrevMonth(month: String): String {
        val parts = month.split("-")
        var y = parts[0].toInt()
        var m = parts[1].toInt() - 1
        if (m < 1) { m = 12; y-- }
        return "%04d-%02d".format(y, m)
    }

    private fun getNextMonth(month: String): String {
        val parts = month.split("-")
        var y = parts[0].toInt()
        var m = parts[1].toInt() + 1
        if (m > 12) { m = 1; y++ }
        return "%04d-%02d".format(y, m)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
