package com.kgshop.ui.auth

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.kgshop.databinding.ActivityLoginBinding
import com.kgshop.ui.admin.AdminMainActivity
import com.kgshop.ui.employee.EmployeeMainActivity
import com.kgshop.utils.SessionManager
import com.kgshop.utils.showToast
import com.kgshop.viewmodel.AuthViewModel

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private val viewModel: AuthViewModel by viewModels()
    private lateinit var session: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        session = SessionManager(this)

        // Auto-login if session exists
        if (session.isLoggedIn()) {
            navigateToMain()
            return
        }

        setupObservers()
        setupClickListeners()
    }

    private fun setupClickListeners() {
        binding.btnLogin.setOnClickListener {
            val code = binding.etEmployeeId.text.toString().trim()
            val password = binding.etPassword.text.toString()
            viewModel.login(code, password)
        }
    }

    private fun setupObservers() {
        viewModel.loginResult.observe(this) { result ->
            when (result) {
                is AuthViewModel.LoginResult.Success -> {
                    val emp = result.employee
                    session.saveSession(emp.id, emp.isAdmin, emp.name)
                    navigateToMain()
                }
                is AuthViewModel.LoginResult.Error -> {
                    showToast(result.message)
                }
            }
        }
    }

    private fun navigateToMain() {
        val intent = if (session.isAdmin()) {
            Intent(this, AdminMainActivity::class.java)
        } else {
            Intent(this, EmployeeMainActivity::class.java)
        }
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
    }
}
