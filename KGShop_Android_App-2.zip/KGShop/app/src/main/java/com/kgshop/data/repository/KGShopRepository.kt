package com.kgshop.data.repository

import android.content.Context
import com.kgshop.data.database.KGShopDatabase
import com.kgshop.data.entities.*
import com.kgshop.utils.DateUtils
import com.kgshop.utils.HashUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class KGShopRepository(context: Context) {

    private val db = KGShopDatabase.getDatabase(context)
    private val employeeDao = db.employeeDao()
    private val attendanceDao = db.attendanceDao()
    private val advanceDao = db.advanceDao()
    private val payrollDao = db.payrollDao()

    // ── Employee ──────────────────────────────────────────────────────────────

    fun getAllActiveEmployees() = employeeDao.getAllActiveEmployees()
    fun getNonAdminEmployees() = employeeDao.getNonAdminEmployees()
    fun getEmployeeByIdLive(id: Long) = employeeDao.getEmployeeByIdLive(id)
    fun getActiveEmployeeCount() = employeeDao.getActiveEmployeeCount()

    suspend fun insertEmployee(employee: Employee) = withContext(Dispatchers.IO) {
        employeeDao.insert(employee)
    }

    suspend fun updateEmployee(employee: Employee) = withContext(Dispatchers.IO) {
        employeeDao.update(employee)
    }

    suspend fun deactivateEmployee(id: Long) = withContext(Dispatchers.IO) {
        employeeDao.deactivateEmployee(id)
    }

    suspend fun login(code: String, password: String): Employee? = withContext(Dispatchers.IO) {
        val hashedPassword = HashUtils.sha256(password)
        val employee = employeeDao.getEmployeeByCode(code)
            ?: employeeDao.getAdmin().takeIf { code.equals("ADMIN", ignoreCase = true) }
        if (employee != null && employee.password == hashedPassword) employee else null
    }

    // ── Attendance ────────────────────────────────────────────────────────────

    fun getAttendanceForEmployee(employeeId: Long) = attendanceDao.getAttendanceForEmployee(employeeId)
    fun getMonthlyAttendance(employeeId: Long, month: String) = attendanceDao.getMonthlyAttendance(employeeId, month)
    fun getAttendanceByDate(date: String) = attendanceDao.getAttendanceByDate(date)
    fun getPresentCountForDate(date: String) = attendanceDao.getPresentCountForDate(date)
    fun getAllAttendanceForMonth(month: String) = attendanceDao.getAllAttendanceForMonth(month)

    suspend fun getTodayAttendance(employeeId: Long): Attendance? = withContext(Dispatchers.IO) {
        attendanceDao.getAttendanceByEmployeeAndDate(employeeId, DateUtils.today())
    }

    suspend fun clockIn(employeeId: Long): Result<Attendance> = withContext(Dispatchers.IO) {
        val today = DateUtils.today()
        val existing = attendanceDao.getAttendanceByEmployeeAndDate(employeeId, today)
        if (existing != null) {
            Result.failure(Exception("Already clocked in today"))
        } else {
            val attendance = Attendance(
                employeeId = employeeId,
                date = today,
                timeIn = DateUtils.currentTime(),
                timeOut = null,
                totalHours = 0.0
            )
            val id = attendanceDao.insert(attendance)
            Result.success(attendance.copy(id = id))
        }
    }

    suspend fun clockOut(attendanceId: Long): Result<Attendance> = withContext(Dispatchers.IO) {
        val attendance = attendanceDao.getAttendanceById(attendanceId)
            ?: return@withContext Result.failure(Exception("Attendance record not found"))
        if (attendance.timeOut != null) {
            return@withContext Result.failure(Exception("Already clocked out"))
        }
        val timeOut = DateUtils.currentTime()
        val hours = DateUtils.calculateHours(attendance.timeIn ?: "00:00:00", timeOut)
        val updated = attendance.copy(timeOut = timeOut, totalHours = hours)
        attendanceDao.update(updated)
        Result.success(updated)
    }

    suspend fun updateAttendance(attendance: Attendance) = withContext(Dispatchers.IO) {
        attendanceDao.update(attendance)
    }

    suspend fun insertAttendance(attendance: Attendance) = withContext(Dispatchers.IO) {
        attendanceDao.insert(attendance)
    }

    // ── Advances ──────────────────────────────────────────────────────────────

    fun getAdvancesForEmployee(employeeId: Long) = advanceDao.getAdvancesForEmployee(employeeId)
    fun getAllAdvances() = advanceDao.getAllAdvances()

    suspend fun insertAdvance(advance: Advance) = withContext(Dispatchers.IO) {
        advanceDao.insert(advance)
    }

    suspend fun deleteAdvance(advance: Advance) = withContext(Dispatchers.IO) {
        advanceDao.delete(advance)
    }

    suspend fun getTotalAdvanceForMonth(employeeId: Long, month: String): Double = withContext(Dispatchers.IO) {
        advanceDao.getTotalAdvanceForMonth(employeeId, month) ?: 0.0
    }

    // ── Payroll ───────────────────────────────────────────────────────────────

    fun getPayrollForEmployee(employeeId: Long) = payrollDao.getPayrollForEmployee(employeeId)
    fun getAllPayrollForMonth(month: String) = payrollDao.getAllPayrollForMonth(month)
    fun getTotalPayableForMonth(month: String) = payrollDao.getTotalPayableForMonth(month)
    fun getAllPayroll() = payrollDao.getAllPayroll()

    suspend fun generatePayroll(employee: Employee, month: String): Payroll = withContext(Dispatchers.IO) {
        val workingDays = DateUtils.getWorkingDaysInMonth(month)
        val presentDays = attendanceDao.getPresentDaysInMonth(employee.id, month)
        val absentDays = workingDays - presentDays
        val advanceAmount = advanceDao.getTotalAdvanceForMonth(employee.id, month) ?: 0.0

        val grossSalary: Double
        val deductions: Double

        if (employee.salaryType == SalaryType.MONTHLY) {
            val perDayAmount = employee.salaryAmount / workingDays
            deductions = perDayAmount * absentDays
            grossSalary = employee.salaryAmount
        } else {
            grossSalary = presentDays * employee.salaryAmount
            deductions = 0.0
        }

        val netSalary = grossSalary - deductions - advanceAmount

        val payroll = Payroll(
            employeeId = employee.id,
            month = month,
            totalWorkingDays = workingDays,
            presentDays = presentDays,
            absentDays = absentDays,
            grossSalary = grossSalary,
            deductions = deductions,
            advanceAmount = advanceAmount,
            netSalary = netSalary.coerceAtLeast(0.0),
            generatedAt = DateUtils.today()
        )

        val existing = payrollDao.getPayrollForMonth(employee.id, month)
        if (existing != null) {
            val updated = payroll.copy(id = existing.id, isPaid = existing.isPaid)
            payrollDao.update(updated)
            updated
        } else {
            val id = payrollDao.insert(payroll)
            payroll.copy(id = id)
        }
    }

    suspend fun markPayrollAsPaid(employeeId: Long, month: String) = withContext(Dispatchers.IO) {
        val payroll = payrollDao.getPayrollForMonth(employeeId, month) ?: return@withContext
        payrollDao.update(payroll.copy(isPaid = true))
    }

    suspend fun getAllActiveEmployeesList() = withContext(Dispatchers.IO) {
        employeeDao.getAllActiveEmployeesList()
    }

    suspend fun getEmployeeById(id: Long) = withContext(Dispatchers.IO) {
        employeeDao.getEmployeeById(id)
    }
}
