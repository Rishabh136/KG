package com.kgshop.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.kgshop.data.entities.Payroll

@Dao
interface PayrollDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(payroll: Payroll): Long

    @Update
    suspend fun update(payroll: Payroll)

    @Delete
    suspend fun delete(payroll: Payroll)

    @Query("SELECT * FROM payroll WHERE employeeId = :employeeId ORDER BY month DESC")
    fun getPayrollForEmployee(employeeId: Long): LiveData<List<Payroll>>

    @Query("SELECT * FROM payroll WHERE employeeId = :employeeId AND month = :month LIMIT 1")
    suspend fun getPayrollForMonth(employeeId: Long, month: String): Payroll?

    @Query("SELECT * FROM payroll WHERE month = :month ORDER BY employeeId")
    fun getAllPayrollForMonth(month: String): LiveData<List<Payroll>>

    @Query("SELECT SUM(netSalary) FROM payroll WHERE month = :month")
    fun getTotalPayableForMonth(month: String): LiveData<Double?>

    @Query("SELECT * FROM payroll ORDER BY month DESC, employeeId ASC")
    fun getAllPayroll(): LiveData<List<Payroll>>
}
