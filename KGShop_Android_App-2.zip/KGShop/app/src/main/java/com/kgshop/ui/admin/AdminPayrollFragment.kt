package com.kgshop.ui.admin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.kgshop.databinding.FragmentAdminPayrollBinding
import com.kgshop.ui.admin.adapters.PayrollAdapter
import com.kgshop.utils.DateUtils
import com.kgshop.utils.formatAmount
import com.kgshop.utils.showToast
import com.kgshop.viewmodel.PayrollViewModel

class AdminPayrollFragment : Fragment() {

    private var _binding: FragmentAdminPayrollBinding? = null
    private val binding get() = _binding!!
    private val viewModel: PayrollViewModel by viewModels()
    private lateinit var adapter: PayrollAdapter
    private var currentMonth = DateUtils.currentMonth()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAdminPayrollBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        updateMonthDisplay()
        setupRecyclerView()
        loadPayroll()

        binding.btnPrevMonth.setOnClickListener {
            currentMonth = getPrevMonth(currentMonth)
            updateMonthDisplay()
            loadPayroll()
        }
        binding.btnNextMonth.setOnClickListener {
            currentMonth = getNextMonth(currentMonth)
            updateMonthDisplay()
            loadPayroll()
        }

        binding.btnGeneratePayroll.setOnClickListener {
            viewModel.generateAllPayrolls(currentMonth)
        }

        viewModel.operationResult.observe(viewLifecycleOwner) {
            when (it) {
                is PayrollViewModel.OperationResult.Success -> requireContext().showToast(it.message)
                is PayrollViewModel.OperationResult.Error -> requireContext().showToast(it.message)
            }
        }

        viewModel.getTotalPayableForMonth(currentMonth).observe(viewLifecycleOwner) { total ->
            binding.tvTotalPayable.text = "Total Payable: PKR ${(total ?: 0.0).formatAmount()}"
        }
    }

    private fun setupRecyclerView() {
        adapter = PayrollAdapter { payroll ->
            viewModel.markAsPaid(payroll.employeeId, payroll.month)
        }
        binding.rvPayroll.layoutManager = LinearLayoutManager(requireContext())
        binding.rvPayroll.adapter = adapter
    }

    private fun loadPayroll() {
        viewModel.getAllPayrollForMonth(currentMonth).observe(viewLifecycleOwner) { list ->
            adapter.submitList(list)
            binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun updateMonthDisplay() {
        binding.tvCurrentMonth.text = DateUtils.formatMonthForDisplay(currentMonth)
    }

    private fun getPrevMonth(month: String): String {
        val parts = month.split("-")
        var y = parts[0].toInt(); var m = parts[1].toInt() - 1
        if (m < 1) { m = 12; y-- }
        return "%04d-%02d".format(y, m)
    }

    private fun getNextMonth(month: String): String {
        val parts = month.split("-")
        var y = parts[0].toInt(); var m = parts[1].toInt() + 1
        if (m > 12) { m = 1; y++ }
        return "%04d-%02d".format(y, m)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
