package com.kgshop.ui.employee

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.kgshop.databinding.FragmentEmployeeDashboardBinding
import com.kgshop.utils.DateUtils
import com.kgshop.utils.SessionManager
import com.kgshop.utils.showToast
import com.kgshop.viewmodel.AttendanceViewModel

class EmployeeDashboardFragment : Fragment() {

    private var _binding: FragmentEmployeeDashboardBinding? = null
    private val binding get() = _binding!!
    private val attendanceVM: AttendanceViewModel by viewModels()
    private lateinit var session: SessionManager

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentEmployeeDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        session = SessionManager(requireContext())
        val empId = session.getEmployeeId()

        binding.tvGreeting.text = "Hello, ${session.getEmployeeName()}!"
        binding.tvDate.text = DateUtils.formatDateForDisplay(DateUtils.today())

        attendanceVM.loadTodayAttendance(empId)
        attendanceVM.todayAttendance.observe(viewLifecycleOwner) { att ->
            if (att == null) {
                binding.tvStatus.text = "Not Clocked In"
                binding.btnClockIn.isEnabled = true
                binding.btnClockOut.isEnabled = false
                binding.tvTimeIn.text = "Time In: --"
                binding.tvTimeOut.text = "Time Out: --"
            } else {
                binding.tvTimeIn.text = "Time In: ${DateUtils.formatTimeForDisplay(att.timeIn)}"
                if (att.timeOut != null) {
                    binding.tvStatus.text = "Work Done ✓"
                    binding.btnClockIn.isEnabled = false
                    binding.btnClockOut.isEnabled = false
                    binding.tvTimeOut.text = "Time Out: ${DateUtils.formatTimeForDisplay(att.timeOut)}"
                    binding.tvHours.text = "Total: %.1f hours".format(att.totalHours)
                } else {
                    binding.tvStatus.text = "Clocked In 🟢"
                    binding.btnClockIn.isEnabled = false
                    binding.btnClockOut.isEnabled = true
                    binding.tvTimeOut.text = "Time Out: --"
                }
            }
        }

        binding.btnClockIn.setOnClickListener {
            attendanceVM.clockIn(empId)
        }

        binding.btnClockOut.setOnClickListener {
            attendanceVM.todayAttendance.value?.let { att ->
                attendanceVM.clockOut(att)
            }
        }

        attendanceVM.operationResult.observe(viewLifecycleOwner) {
            when (it) {
                is AttendanceViewModel.OperationResult.Success -> requireContext().showToast(it.message)
                is AttendanceViewModel.OperationResult.Error -> requireContext().showToast(it.message)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
