package com.kgshop.ui.admin

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.fragment.app.DialogFragment
import com.kgshop.data.entities.Employee
import com.kgshop.data.entities.SalaryType
import com.kgshop.databinding.DialogAddEditEmployeeBinding
import com.kgshop.utils.DateUtils
import com.kgshop.utils.HashUtils
import java.util.Calendar

class AddEditEmployeeDialog(
    private val employee: Employee?,
    private val onSave: (Employee) -> Unit
) : DialogFragment() {

    private var _binding: DialogAddEditEmployeeBinding? = null
    private val binding get() = _binding!!
    private var selectedDate = DateUtils.today()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = DialogAddEditEmployeeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val salaryTypes = arrayOf("Monthly Salary", "Daily Wage")
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, salaryTypes)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerSalaryType.adapter = adapter

        employee?.let { emp ->
            binding.tvDialogTitle.text = "Edit Employee"
            binding.etEmployeeCode.setText(emp.employeeCode)
            binding.etEmployeeCode.isEnabled = false
            binding.etName.setText(emp.name)
            binding.etPhone.setText(emp.phone)
            binding.etSalaryAmount.setText(emp.salaryAmount.toString())
            binding.spinnerSalaryType.setSelection(if (emp.salaryType == SalaryType.MONTHLY) 0 else 1)
            selectedDate = emp.joiningDate
            binding.tvJoiningDate.text = DateUtils.formatDateForDisplay(emp.joiningDate)
            binding.tilPassword.hint = "New Password (leave blank to keep)"
        } ?: run {
            binding.tvDialogTitle.text = "Add Employee"
        }

        binding.tvJoiningDate.setOnClickListener { showDatePicker() }
        binding.btnPickDate.setOnClickListener { showDatePicker() }

        binding.btnSave.setOnClickListener {
            val code = binding.etEmployeeCode.text.toString().trim()
            val name = binding.etName.text.toString().trim()
            val phone = binding.etPhone.text.toString().trim()
            val password = binding.etPassword.text.toString()
            val salaryAmount = binding.etSalaryAmount.text.toString().toDoubleOrNull() ?: 0.0
            val salaryType = if (binding.spinnerSalaryType.selectedItemPosition == 0)
                SalaryType.MONTHLY else SalaryType.DAILY

            if (code.isBlank() || name.isBlank() || phone.isBlank()) {
                binding.etName.error = if (name.isBlank()) "Required" else null
                return@setOnClickListener
            }
            if (employee == null && password.isBlank()) {
                binding.etPassword.error = "Password is required"
                return@setOnClickListener
            }

            val emp = Employee(
                id = employee?.id ?: 0,
                employeeCode = code.uppercase(),
                name = name,
                phone = phone,
                password = if (password.isNotBlank()) HashUtils.sha256(password)
                           else employee?.password ?: HashUtils.sha256("password123"),
                salaryType = salaryType,
                salaryAmount = salaryAmount,
                joiningDate = selectedDate
            )
            onSave(emp)
            dismiss()
        }

        binding.btnCancel.setOnClickListener { dismiss() }
    }

    private fun showDatePicker() {
        val cal = Calendar.getInstance()
        DatePickerDialog(requireContext(), { _, y, m, d ->
            selectedDate = "%04d-%02d-%02d".format(y, m + 1, d)
            binding.tvJoiningDate.text = DateUtils.formatDateForDisplay(selectedDate)
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
