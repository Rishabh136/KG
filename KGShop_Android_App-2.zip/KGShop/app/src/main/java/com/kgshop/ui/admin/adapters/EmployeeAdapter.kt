package com.kgshop.ui.admin.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.kgshop.data.entities.Employee
import com.kgshop.data.entities.SalaryType
import com.kgshop.databinding.ItemEmployeeBinding
import com.kgshop.utils.DateUtils
import com.kgshop.utils.formatAmount

class EmployeeAdapter(
    private val onEdit: (Employee) -> Unit,
    private val onDelete: (Employee) -> Unit
) : ListAdapter<Employee, EmployeeAdapter.VH>(DIFF) {

    inner class VH(val binding: ItemEmployeeBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemEmployeeBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val emp = getItem(position)
        with(holder.binding) {
            tvEmployeeName.text = emp.name
            tvEmployeeCode.text = "ID: ${emp.employeeCode}"
            tvPhone.text = "📞 ${emp.phone}"
            tvSalaryType.text = if (emp.salaryType == SalaryType.MONTHLY) "Monthly" else "Daily"
            tvSalaryAmount.text = "PKR ${emp.salaryAmount.formatAmount()}"
            tvJoiningDate.text = "Joined: ${DateUtils.formatDateForDisplay(emp.joiningDate)}"
            btnEdit.setOnClickListener { onEdit(emp) }
            btnDelete.setOnClickListener { onDelete(emp) }
        }
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Employee>() {
            override fun areItemsTheSame(a: Employee, b: Employee) = a.id == b.id
            override fun areContentsTheSame(a: Employee, b: Employee) = a == b
        }
    }
}
