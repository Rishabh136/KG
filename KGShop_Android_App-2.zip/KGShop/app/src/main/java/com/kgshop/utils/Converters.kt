package com.kgshop.utils

import androidx.room.TypeConverter
import com.kgshop.data.entities.AttendanceStatus
import com.kgshop.data.entities.SalaryType

class Converters {

    @TypeConverter
    fun fromSalaryType(value: SalaryType): String = value.name

    @TypeConverter
    fun toSalaryType(value: String): SalaryType = SalaryType.valueOf(value)

    @TypeConverter
    fun fromAttendanceStatus(value: AttendanceStatus): String = value.name

    @TypeConverter
    fun toAttendanceStatus(value: String): AttendanceStatus = AttendanceStatus.valueOf(value)
}
