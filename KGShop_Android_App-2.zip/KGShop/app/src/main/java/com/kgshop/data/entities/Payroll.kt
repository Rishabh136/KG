package com.kgshop.data.entities

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(
    tableName = "payroll",
    foreignKeys = [
        ForeignKey(
            entity = Employee::class,
            parentColumns = ["id"],
            childColumns = ["employeeId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["employeeId", "month"], unique = true)]
)
data class Payroll(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val employeeId: Long,
    val month: String,          // "yyyy-MM"
    val totalWorkingDays: Int,
    val presentDays: Int,
    val absentDays: Int,
    val grossSalary: Double,
    val deductions: Double,
    val advanceAmount: Double,
    val netSalary: Double,
    val isPaid: Boolean = false,
    val generatedAt: String = ""
) : Parcelable
