package com.kgshop.ui.admin

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.kgshop.databinding.FragmentAdvanceManagementBinding
import com.kgshop.databinding.DialogAddAdvanceBinding
import com.kgshop.ui.admin.adapters.AdvanceAdapter
import com.kgshop.utils.DateUtils
import com.kgshop.utils.showToast
import com.kgshop.viewmodel.EmployeeViewModel
import com.kgshop.viewmodel.PayrollViewModel

class AdvanceManagementFragment : Fragment() {

    private var _binding: FragmentAdvanceManagementBinding? = null
    private val binding get() = _binding!!
    private val payrollVM: PayrollViewModel by viewModels()
    private val employeeVM: EmployeeViewModel by viewModels()
    private lateinit var adapter: AdvanceAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAdvanceManagementBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = AdvanceAdapter { advance ->
            AlertDialog.Builder(requireContext())
                .setTitle("Delete Advance")
                .setMessage("Delete this advance record of PKR ${advance.amount}?")
                .setPositiveButton("Delete") { _, _ -> payrollVM.deleteAdvance(advance) }
                .setNegativeButton("Cancel", null)
                .show()
        }
        binding.rvAdvances.layoutManager = LinearLayoutManager(requireContext())
        binding.rvAdvances.adapter = adapter

        payrollVM.getAllAdvances().observe(viewLifecycleOwner) { advances ->
            adapter.submitList(advances)
            binding.tvEmpty.visibility = if (advances.isEmpty()) View.VISIBLE else View.GONE
        }

        payrollVM.operationResult.observe(viewLifecycleOwner) {
            when (it) {
                is PayrollViewModel.OperationResult.Success -> requireContext().showToast(it.message)
                is PayrollViewModel.OperationResult.Error -> requireContext().showToast(it.message)
            }
        }

        binding.fabAddAdvance.setOnClickListener { showAddAdvanceDialog() }
    }

    private fun showAddAdvanceDialog() {
        val dialogBinding = DialogAddAdvanceBinding.inflate(layoutInflater)
        val employeeIds = mutableListOf<Long>()

        employeeVM.employees.observe(viewLifecycleOwner) { emps ->
            val names = emps.map { "${it.name} (${it.employeeCode})" }
            employeeIds.clear()
            employeeIds.addAll(emps.map { it.id })
            val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, names)
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            dialogBinding.spinnerEmployee.adapter = adapter
        }

        AlertDialog.Builder(requireContext())
            .setTitle("Add Advance")
            .setView(dialogBinding.root)
            .setPositiveButton("Save") { _, _ ->
                val empId = employeeIds.getOrNull(dialogBinding.spinnerEmployee.selectedItemPosition) ?: return@setPositiveButton
                val amount = dialogBinding.etAmount.text.toString().toDoubleOrNull() ?: 0.0
                val note = dialogBinding.etNote.text.toString()
                val month = DateUtils.currentMonth()
                payrollVM.addAdvance(empId, amount, note, month)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
