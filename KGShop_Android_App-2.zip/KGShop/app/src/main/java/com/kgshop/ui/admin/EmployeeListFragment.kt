package com.kgshop.ui.admin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.kgshop.data.entities.Employee
import com.kgshop.databinding.FragmentEmployeeListBinding
import com.kgshop.ui.admin.adapters.EmployeeAdapter
import com.kgshop.utils.showToast
import com.kgshop.viewmodel.EmployeeViewModel

class EmployeeListFragment : Fragment() {

    private var _binding: FragmentEmployeeListBinding? = null
    private val binding get() = _binding!!
    private val viewModel: EmployeeViewModel by viewModels()
    private lateinit var adapter: EmployeeAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentEmployeeListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        observeData()

        binding.fabAddEmployee.setOnClickListener {
            AddEditEmployeeDialog(null) { viewModel.addEmployee(it.employeeCode, it.name, it.phone, "", it.salaryType, it.salaryAmount, it.joiningDate) }
                .show(parentFragmentManager, "AddEmployee")
        }
    }

    private fun setupRecyclerView() {
        adapter = EmployeeAdapter(
            onEdit = { employee -> showEditDialog(employee) },
            onDelete = { employee -> showDeleteDialog(employee) }
        )
        binding.rvEmployees.layoutManager = LinearLayoutManager(requireContext())
        binding.rvEmployees.adapter = adapter
    }

    private fun observeData() {
        viewModel.employees.observe(viewLifecycleOwner) { employees ->
            adapter.submitList(employees)
            binding.tvEmpty.visibility = if (employees.isEmpty()) View.VISIBLE else View.GONE
        }

        viewModel.operationResult.observe(viewLifecycleOwner) { result ->
            when (result) {
                is EmployeeViewModel.OperationResult.Success -> requireContext().showToast(result.message)
                is EmployeeViewModel.OperationResult.Error -> requireContext().showToast(result.message)
            }
        }
    }

    private fun showEditDialog(employee: Employee) {
        AddEditEmployeeDialog(employee) { updated ->
            viewModel.updateEmployee(
                existing = employee,
                name = updated.name,
                phone = updated.phone,
                newPassword = null,
                salaryType = updated.salaryType,
                salaryAmount = updated.salaryAmount,
                joiningDate = updated.joiningDate
            )
        }.show(parentFragmentManager, "EditEmployee")
    }

    private fun showDeleteDialog(employee: Employee) {
        AlertDialog.Builder(requireContext())
            .setTitle("Remove Employee")
            .setMessage("Are you sure you want to remove ${employee.name}?")
            .setPositiveButton("Remove") { _, _ -> viewModel.deleteEmployee(employee) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
