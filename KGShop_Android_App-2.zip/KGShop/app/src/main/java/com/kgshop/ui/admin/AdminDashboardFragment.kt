package com.kgshop.ui.admin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.kgshop.databinding.FragmentAdminDashboardBinding
import com.kgshop.utils.DateUtils
import com.kgshop.utils.formatAmount
import com.kgshop.viewmodel.AttendanceViewModel
import com.kgshop.viewmodel.EmployeeViewModel
import com.kgshop.viewmodel.PayrollViewModel

class AdminDashboardFragment : Fragment() {

    private var _binding: FragmentAdminDashboardBinding? = null
    private val binding get() = _binding!!

    private val employeeVM: EmployeeViewModel by viewModels()
    private val attendanceVM: AttendanceViewModel by viewModels()
    private val payrollVM: PayrollViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAdminDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val today = DateUtils.today()
        val currentMonth = DateUtils.currentMonth()

        binding.tvDate.text = DateUtils.formatDateForDisplay(today)
        binding.tvMonth.text = DateUtils.formatMonthForDisplay(currentMonth)

        employeeVM.activeCount.observe(viewLifecycleOwner) { count ->
            binding.tvTotalEmployees.text = count.toString()
        }

        attendanceVM.getPresentCountForDate(today).observe(viewLifecycleOwner) { present ->
            binding.tvPresentToday.text = present.toString()
            employeeVM.activeCount.value?.let { total ->
                binding.tvAbsentToday.text = (total - present).coerceAtLeast(0).toString()
            }
        }

        employeeVM.activeCount.observe(viewLifecycleOwner) { total ->
            attendanceVM.getPresentCountForDate(today).value?.let { present ->
                binding.tvAbsentToday.text = (total - present).coerceAtLeast(0).toString()
            }
        }

        payrollVM.getTotalPayableForMonth(currentMonth).observe(viewLifecycleOwner) { total ->
            binding.tvTotalSalary.text = "PKR ${(total ?: 0.0).formatAmount()}"
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
