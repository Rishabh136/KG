package com.kgshop.data.entities

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(
    tableName = "attendance",
    foreignKeys = [
        ForeignKey(
            entity = Employee::class,
            parentColumns = ["id"],
            childColumns = ["employeeId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["employeeId", "date"], unique = true)]
)
data class Attendance(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val employeeId: Long,
    val date: String,       // "yyyy-MM-dd"
    val timeIn: String?,    // "HH:mm:ss"
    val timeOut: String?,   // "HH:mm:ss"
    val totalHours: Double = 0.0,
    val status: AttendanceStatus = AttendanceStatus.PRESENT
) : Parcelable

enum class AttendanceStatus {
    PRESENT, ABSENT, HALF_DAY
}
