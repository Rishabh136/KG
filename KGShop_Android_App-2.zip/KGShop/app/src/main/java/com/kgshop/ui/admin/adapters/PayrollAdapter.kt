package com.kgshop.ui.admin.adapters

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.kgshop.data.entities.Payroll
import com.kgshop.databinding.ItemPayrollBinding
import com.kgshop.utils.formatAmount

class PayrollAdapter(
    private val onMarkPaid: (Payroll) -> Unit
) : ListAdapter<Payroll, PayrollAdapter.VH>(DIFF) {

    inner class VH(val binding: ItemPayrollBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemPayrollBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val p = getItem(position)
        with(holder.binding) {
            tvEmployeeId.text = "Emp #${p.employeeId}"
            tvWorkingDays.text = "Working: ${p.totalWorkingDays} | Present: ${p.presentDays} | Absent: ${p.absentDays}"
            tvGrossSalary.text = "Gross: PKR ${p.grossSalary.formatAmount()}"
            tvDeductions.text = "Deductions: PKR ${(p.deductions + p.advanceAmount).formatAmount()}"
            tvNetSalary.text = "Net: PKR ${p.netSalary.formatAmount()}"
            tvAdvance.text = "Advance: PKR ${p.advanceAmount.formatAmount()}"
            tvStatus.text = if (p.isPaid) "✓ PAID" else "PENDING"
            tvStatus.setTextColor(if (p.isPaid) Color.parseColor("#4CAF50") else Color.parseColor("#FF9800"))
            btnMarkPaid.isEnabled = !p.isPaid
            btnMarkPaid.setOnClickListener { onMarkPaid(p) }
        }
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Payroll>() {
            override fun areItemsTheSame(a: Payroll, b: Payroll) = a.id == b.id
            override fun areContentsTheSame(a: Payroll, b: Payroll) = a == b
        }
    }
}
