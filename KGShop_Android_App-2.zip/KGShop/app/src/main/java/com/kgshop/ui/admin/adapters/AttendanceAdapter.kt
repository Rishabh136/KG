package com.kgshop.ui.admin.adapters

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.kgshop.data.entities.Attendance
import com.kgshop.data.entities.AttendanceStatus
import com.kgshop.databinding.ItemAttendanceBinding
import com.kgshop.utils.DateUtils

class AttendanceAdapter(
    private val showEmployeeName: Boolean = false,
    private val onEdit: ((Attendance) -> Unit)? = null
) : ListAdapter<Attendance, AttendanceAdapter.VH>(DIFF) {

    inner class VH(val binding: ItemAttendanceBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemAttendanceBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val att = getItem(position)
        with(holder.binding) {
            tvDate.text = DateUtils.formatDateForDisplay(att.date)
            tvTimeIn.text = "In: ${DateUtils.formatTimeForDisplay(att.timeIn)}"
            tvTimeOut.text = "Out: ${DateUtils.formatTimeForDisplay(att.timeOut)}"
            tvHours.text = "%.1f hrs".format(att.totalHours)
            tvStatus.text = att.status.name
            tvStatus.setTextColor(when (att.status) {
                AttendanceStatus.PRESENT -> Color.parseColor("#4CAF50")
                AttendanceStatus.ABSENT -> Color.parseColor("#F44336")
                AttendanceStatus.HALF_DAY -> Color.parseColor("#FF9800")
            })
            onEdit?.let { callback ->
                root.setOnClickListener { callback(att) }
            }
        }
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Attendance>() {
            override fun areItemsTheSame(a: Attendance, b: Attendance) = a.id == b.id
            override fun areContentsTheSame(a: Attendance, b: Attendance) = a == b
        }
    }
}
