package com.kgshop.ui.employee

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.kgshop.databinding.FragmentEmployeePayrollBinding
import com.kgshop.ui.admin.adapters.PayrollAdapter
import com.kgshop.utils.SessionManager
import com.kgshop.viewmodel.PayrollViewModel

class EmployeePayrollFragment : Fragment() {

    private var _binding: FragmentEmployeePayrollBinding? = null
    private val binding get() = _binding!!
    private val payrollVM: PayrollViewModel by viewModels()
    private lateinit var session: SessionManager
    private lateinit var adapter: PayrollAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentEmployeePayrollBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        session = SessionManager(requireContext())

        adapter = PayrollAdapter { /* employees cannot mark paid */ }
        binding.rvPayroll.layoutManager = LinearLayoutManager(requireContext())
        binding.rvPayroll.adapter = adapter

        payrollVM.getPayrollForEmployee(session.getEmployeeId()).observe(viewLifecycleOwner) { list ->
            adapter.submitList(list)
            binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
