package com.kgshop.ui.employee

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.kgshop.databinding.FragmentEmployeeAttendanceBinding
import com.kgshop.ui.admin.adapters.AttendanceAdapter
import com.kgshop.utils.DateUtils
import com.kgshop.utils.SessionManager
import com.kgshop.viewmodel.AttendanceViewModel

class EmployeeAttendanceFragment : Fragment() {

    private var _binding: FragmentEmployeeAttendanceBinding? = null
    private val binding get() = _binding!!
    private val attendanceVM: AttendanceViewModel by viewModels()
    private lateinit var adapter: AttendanceAdapter
    private lateinit var session: SessionManager
    private var currentMonth = DateUtils.currentMonth()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentEmployeeAttendanceBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        session = SessionManager(requireContext())

        adapter = AttendanceAdapter(showEmployeeName = false)
        binding.rvAttendance.layoutManager = LinearLayoutManager(requireContext())
        binding.rvAttendance.adapter = adapter

        updateMonthDisplay()
        loadAttendance()

        binding.btnPrevMonth.setOnClickListener {
            currentMonth = getPrevMonth(currentMonth)
            updateMonthDisplay(); loadAttendance()
        }
        binding.btnNextMonth.setOnClickListener {
            currentMonth = getNextMonth(currentMonth)
            updateMonthDisplay(); loadAttendance()
        }
    }

    private fun loadAttendance() {
        val empId = session.getEmployeeId()
        attendanceVM.getMonthlyAttendance(empId, currentMonth).observe(viewLifecycleOwner) { list ->
            adapter.submitList(list)
            binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            val present = list.count { it.timeIn != null }
            binding.tvSummary.text = "Present: $present | Total: ${list.size}"
        }
    }

    private fun updateMonthDisplay() {
        binding.tvCurrentMonth.text = DateUtils.formatMonthForDisplay(currentMonth)
    }

    private fun getPrevMonth(m: String): String {
        val p = m.split("-"); var y = p[0].toInt(); var mo = p[1].toInt() - 1
        if (mo < 1) { mo = 12; y-- }; return "%04d-%02d".format(y, mo)
    }
    private fun getNextMonth(m: String): String {
        val p = m.split("-"); var y = p[0].toInt(); var mo = p[1].toInt() + 1
        if (mo > 12) { mo = 1; y++ }; return "%04d-%02d".format(y, mo)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
