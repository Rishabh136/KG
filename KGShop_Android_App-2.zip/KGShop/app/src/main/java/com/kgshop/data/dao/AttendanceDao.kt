package com.kgshop.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.kgshop.data.entities.Attendance

@Dao
interface AttendanceDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(attendance: Attendance): Long

    @Update
    suspend fun update(attendance: Attendance)

    @Delete
    suspend fun delete(attendance: Attendance)

    @Query("SELECT * FROM attendance WHERE employeeId = :employeeId AND date = :date LIMIT 1")
    suspend fun getAttendanceByEmployeeAndDate(employeeId: Long, date: String): Attendance?

    @Query("SELECT * FROM attendance WHERE employeeId = :employeeId ORDER BY date DESC")
    fun getAttendanceForEmployee(employeeId: Long): LiveData<List<Attendance>>

    @Query("SELECT * FROM attendance WHERE employeeId = :employeeId AND date LIKE :monthPrefix || '%' ORDER BY date DESC")
    fun getMonthlyAttendance(employeeId: Long, monthPrefix: String): LiveData<List<Attendance>>

    @Query("SELECT * FROM attendance WHERE employeeId = :employeeId AND date LIKE :monthPrefix || '%'")
    suspend fun getMonthlyAttendanceList(employeeId: Long, monthPrefix: String): List<Attendance>

    @Query("SELECT * FROM attendance WHERE date = :date ORDER BY employeeId")
    fun getAttendanceByDate(date: String): LiveData<List<Attendance>>

    @Query("SELECT COUNT(*) FROM attendance WHERE date = :date AND status = 'PRESENT'")
    fun getPresentCountForDate(date: String): LiveData<Int>

    @Query("SELECT COUNT(*) FROM attendance WHERE employeeId = :employeeId AND date LIKE :monthPrefix || '%' AND status = 'PRESENT'")
    suspend fun getPresentDaysInMonth(employeeId: Long, monthPrefix: String): Int

    @Query("SELECT * FROM attendance WHERE date LIKE :monthPrefix || '%' ORDER BY date DESC, employeeId ASC")
    fun getAllAttendanceForMonth(monthPrefix: String): LiveData<List<Attendance>>

    @Query("SELECT * FROM attendance WHERE id = :id")
    suspend fun getAttendanceById(id: Long): Attendance?
}
