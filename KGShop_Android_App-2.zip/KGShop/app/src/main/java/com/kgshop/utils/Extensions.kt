package com.kgshop.utils

import android.content.Context
import android.view.View
import android.widget.Toast
import com.google.android.material.snackbar.Snackbar
import java.text.NumberFormat
import java.util.Locale

fun View.show() { visibility = View.VISIBLE }
fun View.hide() { visibility = View.GONE }
fun View.invisible() { visibility = View.INVISIBLE }

fun Context.showToast(message: String) {
    Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}

fun View.showSnackbar(message: String, duration: Int = Snackbar.LENGTH_SHORT) {
    Snackbar.make(this, message, duration).show()
}

fun Double.toCurrency(): String {
    val format = NumberFormat.getCurrencyInstance(Locale("en", "PK"))
    return format.format(this)
}

fun Double.formatAmount(): String {
    return String.format(Locale.getDefault(), "%.2f", this)
}
