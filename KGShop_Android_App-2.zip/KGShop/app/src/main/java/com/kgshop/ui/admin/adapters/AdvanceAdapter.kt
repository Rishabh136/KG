package com.kgshop.ui.admin.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.kgshop.data.entities.Advance
import com.kgshop.databinding.ItemAdvanceBinding
import com.kgshop.utils.DateUtils
import com.kgshop.utils.formatAmount

class AdvanceAdapter(
    private val onDelete: (Advance) -> Unit
) : ListAdapter<Advance, AdvanceAdapter.VH>(DIFF) {

    inner class VH(val binding: ItemAdvanceBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemAdvanceBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val adv = getItem(position)
        with(holder.binding) {
            tvAmount.text = "PKR ${adv.amount.formatAmount()}"
            tvDate.text = DateUtils.formatDateForDisplay(adv.date)
            tvMonth.text = "Month: ${DateUtils.formatMonthForDisplay(adv.month)}"
            tvNote.text = if (adv.note.isNotBlank()) adv.note else "No note"
            btnDelete.setOnClickListener { onDelete(adv) }
        }
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Advance>() {
            override fun areItemsTheSame(a: Advance, b: Advance) = a.id == b.id
            override fun areContentsTheSame(a: Advance, b: Advance) = a == b
        }
    }
}
