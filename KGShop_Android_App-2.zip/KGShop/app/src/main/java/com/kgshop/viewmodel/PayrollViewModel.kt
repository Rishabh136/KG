package com.kgshop.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.kgshop.data.entities.Advance
import com.kgshop.data.entities.Employee
import com.kgshop.data.entities.Payroll
import com.kgshop.data.repository.KGShopRepository
import com.kgshop.utils.DateUtils
import kotlinx.coroutines.launch

class PayrollViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = KGShopRepository(application)

    val operationResult = MutableLiveData<OperationResult>()
    val generatedPayrolls = MutableLiveData<List<Payroll>>()

    fun getPayrollForEmployee(employeeId: Long) = repository.getPayrollForEmployee(employeeId)
    fun getAllPayrollForMonth(month: String) = repository.getAllPayrollForMonth(month)
    fun getTotalPayableForMonth(month: String) = repository.getTotalPayableForMonth(month)
    fun getAdvancesForEmployee(employeeId: Long) = repository.getAdvancesForEmployee(employeeId)
    fun getAllAdvances() = repository.getAllAdvances()
    fun getAllPayroll() = repository.getAllPayroll()

    fun generateAllPayrolls(month: String) {
        viewModelScope.launch {
            val employees = repository.getAllActiveEmployeesList().filter { !it.isAdmin }
            val payrolls = mutableListOf<Payroll>()
            for (emp in employees) {
                val p = repository.generatePayroll(emp, month)
                payrolls.add(p)
            }
            generatedPayrolls.value = payrolls
            operationResult.value = OperationResult.Success("Payroll generated for ${payrolls.size} employees")
        }
    }

    fun generatePayrollForEmployee(employee: Employee, month: String) {
        viewModelScope.launch {
            val p = repository.generatePayroll(employee, month)
            operationResult.value = OperationResult.Success("Payroll generated successfully")
        }
    }

    fun markAsPaid(employeeId: Long, month: String) {
        viewModelScope.launch {
            repository.markPayrollAsPaid(employeeId, month)
            operationResult.value = OperationResult.Success("Marked as paid")
        }
    }

    fun addAdvance(employeeId: Long, amount: Double, note: String, month: String) {
        if (amount <= 0) {
            operationResult.value = OperationResult.Error("Amount must be greater than 0")
            return
        }
        viewModelScope.launch {
            val advance = Advance(
                employeeId = employeeId,
                amount = amount,
                date = DateUtils.today(),
                month = month,
                note = note
            )
            repository.insertAdvance(advance)
            operationResult.value = OperationResult.Success("Advance recorded successfully")
        }
    }

    fun deleteAdvance(advance: Advance) {
        viewModelScope.launch {
            repository.deleteAdvance(advance)
            operationResult.value = OperationResult.Success("Advance deleted")
        }
    }

    sealed class OperationResult {
        data class Success(val message: String) : OperationResult()
        data class Error(val message: String) : OperationResult()
    }
}
