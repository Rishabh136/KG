package com.kgshop.utils

import java.text.SimpleDateFormat
import java.util.*

object DateUtils {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private val displayDateFormat = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    private val displayTimeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
    private val monthFormat = SimpleDateFormat("yyyy-MM", Locale.getDefault())
    private val displayMonthFormat = SimpleDateFormat("MMMM yyyy", Locale.getDefault())

    fun today(): String = dateFormat.format(Date())

    fun currentTime(): String = timeFormat.format(Date())

    fun currentMonth(): String = monthFormat.format(Date())

    fun formatDateForDisplay(date: String): String {
        return try {
            val d = dateFormat.parse(date) ?: return date
            displayDateFormat.format(d)
        } catch (e: Exception) { date }
    }

    fun formatTimeForDisplay(time: String?): String {
        if (time == null) return "--"
        return try {
            val t = timeFormat.parse(time) ?: return time
            displayTimeFormat.format(t)
        } catch (e: Exception) { time }
    }

    fun formatMonthForDisplay(month: String): String {
        return try {
            val d = monthFormat.parse(month) ?: return month
            displayMonthFormat.format(d)
        } catch (e: Exception) { month }
    }

    fun calculateHours(timeIn: String, timeOut: String): Double {
        return try {
            val inTime = timeFormat.parse(timeIn) ?: return 0.0
            val outTime = timeFormat.parse(timeOut) ?: return 0.0
            val diff = outTime.time - inTime.time
            if (diff < 0) 0.0 else diff / (1000.0 * 60 * 60)
        } catch (e: Exception) { 0.0 }
    }

    /**
     * Returns the number of working days (Mon–Sat) in the given month string "yyyy-MM".
     */
    fun getWorkingDaysInMonth(month: String): Int {
        return try {
            val cal = Calendar.getInstance()
            val d = monthFormat.parse(month) ?: return 26
            cal.time = d
            val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
            var workingDays = 0
            for (day in 1..daysInMonth) {
                cal.set(Calendar.DAY_OF_MONTH, day)
                val dow = cal.get(Calendar.DAY_OF_WEEK)
                if (dow != Calendar.SUNDAY) workingDays++
            }
            workingDays
        } catch (e: Exception) { 26 }
    }

    fun getMonthFromDate(date: String): String {
        return try {
            val d = dateFormat.parse(date) ?: return currentMonth()
            monthFormat.format(d)
        } catch (e: Exception) { currentMonth() }
    }
}
