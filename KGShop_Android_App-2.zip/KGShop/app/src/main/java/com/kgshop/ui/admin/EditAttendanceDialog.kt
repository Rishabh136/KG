package com.kgshop.ui.admin

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.viewModels
import com.kgshop.data.entities.Attendance
import com.kgshop.data.entities.AttendanceStatus
import com.kgshop.databinding.DialogEditAttendanceBinding
import com.kgshop.utils.DateUtils
import com.kgshop.viewmodel.EmployeeViewModel
import java.util.Calendar

class EditAttendanceDialog(
    private val attendance: Attendance?,
    private val onSave: (Attendance) -> Unit
) : DialogFragment() {

    private var _binding: DialogEditAttendanceBinding? = null
    private val binding get() = _binding!!
    private val employeeVM: EmployeeViewModel by viewModels()
    private var selectedDate = attendance?.date ?: DateUtils.today()
    private var selectedTimeIn = attendance?.timeIn ?: ""
    private var selectedTimeOut = attendance?.timeOut ?: ""

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = DialogEditAttendanceBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val statusOptions = arrayOf("Present", "Absent", "Half Day")
        val statusAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, statusOptions)
        statusAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerStatus.adapter = statusAdapter

        // Employee spinner
        val employeeNames = mutableListOf<String>()
        val employeeIds = mutableListOf<Long>()
        employeeVM.employees.observe(viewLifecycleOwner) { emps ->
            employeeNames.clear()
            employeeIds.clear()
            emps.forEach { e -> employeeNames.add("${e.name} (${e.employeeCode})"); employeeIds.add(e.id) }
            val empAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, employeeNames)
            empAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            binding.spinnerEmployee.adapter = empAdapter
            attendance?.let { a ->
                val idx = employeeIds.indexOf(a.employeeId)
                if (idx >= 0) binding.spinnerEmployee.setSelection(idx)
            }
        }

        if (attendance != null) {
            binding.tvDialogTitle.text = "Edit Attendance"
            binding.spinnerEmployee.isEnabled = false
            binding.tvDate.text = DateUtils.formatDateForDisplay(selectedDate)
            binding.tvTimeIn.text = DateUtils.formatTimeForDisplay(selectedTimeIn)
            binding.tvTimeOut.text = DateUtils.formatTimeForDisplay(selectedTimeOut.ifBlank { null })
            binding.spinnerStatus.setSelection(when (attendance.status) {
                AttendanceStatus.PRESENT -> 0
                AttendanceStatus.ABSENT -> 1
                AttendanceStatus.HALF_DAY -> 2
            })
        } else {
            binding.tvDialogTitle.text = "Add Attendance"
            binding.tvDate.text = DateUtils.formatDateForDisplay(selectedDate)
        }

        binding.tvDate.setOnClickListener { showDatePicker() }
        binding.btnTimeIn.setOnClickListener { showTimePicker(true) }
        binding.btnTimeOut.setOnClickListener { showTimePicker(false) }

        binding.btnSave.setOnClickListener {
            val empId = if (employeeIds.isNotEmpty())
                employeeIds.getOrNull(binding.spinnerEmployee.selectedItemPosition) ?: -1L
            else attendance?.employeeId ?: -1L

            if (empId < 0) return@setOnClickListener

            val status = when (binding.spinnerStatus.selectedItemPosition) {
                0 -> AttendanceStatus.PRESENT
                1 -> AttendanceStatus.ABSENT
                else -> AttendanceStatus.HALF_DAY
            }
            val hours = if (selectedTimeIn.isNotBlank() && selectedTimeOut.isNotBlank())
                DateUtils.calculateHours(selectedTimeIn, selectedTimeOut) else 0.0

            onSave(Attendance(
                id = attendance?.id ?: 0,
                employeeId = empId,
                date = selectedDate,
                timeIn = selectedTimeIn.ifBlank { null },
                timeOut = selectedTimeOut.ifBlank { null },
                totalHours = hours,
                status = status
            ))
            dismiss()
        }
        binding.btnCancel.setOnClickListener { dismiss() }
    }

    private fun showDatePicker() {
        val cal = Calendar.getInstance()
        DatePickerDialog(requireContext(), { _, y, m, d ->
            selectedDate = "%04d-%02d-%02d".format(y, m + 1, d)
            binding.tvDate.text = DateUtils.formatDateForDisplay(selectedDate)
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun showTimePicker(isTimeIn: Boolean) {
        val cal = Calendar.getInstance()
        TimePickerDialog(requireContext(), { _, h, m ->
            val timeStr = "%02d:%02d:00".format(h, m)
            if (isTimeIn) {
                selectedTimeIn = timeStr
                binding.tvTimeIn.text = DateUtils.formatTimeForDisplay(timeStr)
            } else {
                selectedTimeOut = timeStr
                binding.tvTimeOut.text = DateUtils.formatTimeForDisplay(timeStr)
            }
        }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), false).show()
    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
