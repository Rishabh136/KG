package com.kgshop.ui.admin

import android.os.Bundle
import android.os.Environment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.kgshop.data.entities.Employee
import com.kgshop.data.entities.Payroll
import com.kgshop.databinding.FragmentReportsBinding
import com.kgshop.utils.DateUtils
import com.kgshop.utils.showToast
import com.kgshop.viewmodel.EmployeeViewModel
import com.kgshop.viewmodel.PayrollViewModel
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream

class ReportsFragment : Fragment() {

    private var _binding: FragmentReportsBinding? = null
    private val binding get() = _binding!!
    private val payrollVM: PayrollViewModel by viewModels()
    private val employeeVM: EmployeeViewModel by viewModels()
    private var currentMonth = DateUtils.currentMonth()
    private var allEmployees = listOf<Employee>()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentReportsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.tvSelectedMonth.text = DateUtils.formatMonthForDisplay(currentMonth)

        binding.btnPrevMonth.setOnClickListener {
            currentMonth = getPrevMonth(currentMonth)
            binding.tvSelectedMonth.text = DateUtils.formatMonthForDisplay(currentMonth)
        }
        binding.btnNextMonth.setOnClickListener {
            currentMonth = getNextMonth(currentMonth)
            binding.tvSelectedMonth.text = DateUtils.formatMonthForDisplay(currentMonth)
        }

        employeeVM.employees.observe(viewLifecycleOwner) { emps ->
            allEmployees = emps
        }

        binding.btnExportPdf.setOnClickListener {
            payrollVM.getAllPayrollForMonth(currentMonth).observe(viewLifecycleOwner) { payrolls ->
                exportToPdf(payrolls, allEmployees, currentMonth)
            }
        }

        binding.btnViewSummary.setOnClickListener {
            payrollVM.getAllPayrollForMonth(currentMonth).observe(viewLifecycleOwner) { payrolls ->
                showSummary(payrolls)
            }
        }
    }

    private fun showSummary(payrolls: List<Payroll>) {
        if (payrolls.isEmpty()) {
            requireContext().showToast("No payroll data for this month")
            return
        }
        val sb = StringBuilder()
        var total = 0.0
        payrolls.forEach { p ->
            val emp = allEmployees.find { it.id == p.employeeId }
            sb.append("${emp?.name ?: "Unknown"}: PKR ${String.format("%.2f", p.netSalary)}\n")
            total += p.netSalary
        }
        sb.append("\nTotal Payable: PKR ${String.format("%.2f", total)}")
        binding.tvSummary.text = sb.toString()
        binding.tvSummary.visibility = View.VISIBLE
    }

    private fun exportToPdf(payrolls: List<Payroll>, employees: List<Employee>, month: String) {
        try {
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas: Canvas = page.canvas

            val titlePaint = Paint().apply { color = Color.parseColor("#1565C0"); textSize = 24f; isFakeBoldText = true }
            val headerPaint = Paint().apply { color = Color.WHITE; textSize = 12f; isFakeBoldText = true }
            val bodyPaint = Paint().apply { color = Color.BLACK; textSize = 10f }
            val bgPaint = Paint().apply { color = Color.parseColor("#1565C0") }

            // Title
            canvas.drawText("KG Shop", 40f, 50f, titlePaint)
            titlePaint.textSize = 14f
            titlePaint.color = Color.BLACK
            canvas.drawText("Payroll Report - ${DateUtils.formatMonthForDisplay(month)}", 40f, 75f, titlePaint)
            canvas.drawText("Generated: ${DateUtils.formatDateForDisplay(DateUtils.today())}", 40f, 92f, bodyPaint)

            // Table header
            canvas.drawRect(40f, 105f, 555f, 125f, bgPaint)
            val cols = listOf(40f, 150f, 230f, 310f, 390f, 470f)
            val headers = listOf("Name", "Working Days", "Present", "Gross Salary", "Deduction", "Net Salary")
            headers.forEachIndexed { i, h -> canvas.drawText(h, cols[i] + 4, 119f, headerPaint) }

            var y = 145f
            var total = 0.0
            val rowAlt = Paint().apply { color = Color.parseColor("#E3F2FD") }

            payrolls.forEachIndexed { idx, p ->
                val emp = employees.find { it.id == p.employeeId }
                if (idx % 2 == 0) canvas.drawRect(40f, y - 14f, 555f, y + 4f, rowAlt)
                canvas.drawText(emp?.name?.take(15) ?: "-", cols[0] + 4, y, bodyPaint)
                canvas.drawText("${p.totalWorkingDays}", cols[1] + 4, y, bodyPaint)
                canvas.drawText("${p.presentDays}", cols[2] + 4, y, bodyPaint)
                canvas.drawText("%.0f".format(p.grossSalary), cols[3] + 4, y, bodyPaint)
                canvas.drawText("%.0f".format(p.deductions + p.advanceAmount), cols[4] + 4, y, bodyPaint)
                canvas.drawText("%.0f".format(p.netSalary), cols[5] + 4, y, bodyPaint)
                total += p.netSalary
                y += 22f
            }

            // Total row
            val totalPaint = Paint().apply { color = Color.BLACK; textSize = 11f; isFakeBoldText = true }
            canvas.drawLine(40f, y, 555f, y, totalPaint)
            y += 16f
            canvas.drawText("TOTAL PAYABLE:", cols[4] + 4, y, totalPaint)
            canvas.drawText("PKR %.2f".format(total), cols[5] + 4, y, totalPaint)

            pdfDocument.finishPage(page)

            // Save file
            val dir = requireContext().getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
            dir?.mkdirs()
            val file = File(dir, "payroll_$month.pdf")
            pdfDocument.writeTo(FileOutputStream(file))
            pdfDocument.close()

            // Share
            val uri = FileProvider.getUriForFile(requireContext(), "${requireContext().packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "Open PDF"))
            requireContext().showToast("PDF saved: ${file.absolutePath}")
        } catch (e: Exception) {
            requireContext().showToast("Error generating PDF: ${e.message}")
        }
    }

    private fun getPrevMonth(m: String): String {
        val p = m.split("-"); var y = p[0].toInt(); var mo = p[1].toInt() - 1
        if (mo < 1) { mo = 12; y-- }; return "%04d-%02d".format(y, mo)
    }
    private fun getNextMonth(m: String): String {
        val p = m.split("-"); var y = p[0].toInt(); var mo = p[1].toInt() + 1
        if (mo > 12) { mo = 1; y++ }; return "%04d-%02d".format(y, mo)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
