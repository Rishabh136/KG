package com.kgshop.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.kgshop.data.entities.Employee
import com.kgshop.data.entities.SalaryType
import com.kgshop.data.repository.KGShopRepository
import com.kgshop.utils.DateUtils
import com.kgshop.utils.HashUtils
import kotlinx.coroutines.launch

class EmployeeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = KGShopRepository(application)

    val employees = repository.getNonAdminEmployees()
    val activeCount = repository.getActiveEmployeeCount()

    val operationResult = MutableLiveData<OperationResult>()

    fun addEmployee(
        code: String,
        name: String,
        phone: String,
        password: String,
        salaryType: SalaryType,
        salaryAmount: Double,
        joiningDate: String
    ) {
        if (code.isBlank() || name.isBlank() || phone.isBlank() || password.isBlank()) {
            operationResult.value = OperationResult.Error("Please fill all required fields")
            return
        }
        viewModelScope.launch {
            val employee = Employee(
                employeeCode = code.trim().uppercase(),
                name = name.trim(),
                phone = phone.trim(),
                password = HashUtils.sha256(password),
                salaryType = salaryType,
                salaryAmount = salaryAmount,
                joiningDate = joiningDate
            )
            repository.insertEmployee(employee)
            operationResult.value = OperationResult.Success("Employee added successfully")
        }
    }

    fun updateEmployee(
        existing: Employee,
        name: String,
        phone: String,
        newPassword: String?,
        salaryType: SalaryType,
        salaryAmount: Double,
        joiningDate: String
    ) {
        if (name.isBlank() || phone.isBlank()) {
            operationResult.value = OperationResult.Error("Name and phone cannot be empty")
            return
        }
        viewModelScope.launch {
            val hashedPassword = if (!newPassword.isNullOrBlank()) {
                HashUtils.sha256(newPassword)
            } else {
                existing.password
            }
            val updated = existing.copy(
                name = name.trim(),
                phone = phone.trim(),
                password = hashedPassword,
                salaryType = salaryType,
                salaryAmount = salaryAmount,
                joiningDate = joiningDate
            )
            repository.updateEmployee(updated)
            operationResult.value = OperationResult.Success("Employee updated successfully")
        }
    }

    fun deleteEmployee(employee: Employee) {
        viewModelScope.launch {
            repository.deactivateEmployee(employee.id)
            operationResult.value = OperationResult.Success("Employee removed successfully")
        }
    }

    sealed class OperationResult {
        data class Success(val message: String) : OperationResult()
        data class Error(val message: String) : OperationResult()
    }
}
