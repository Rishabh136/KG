package com.kgshop.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.kgshop.data.entities.Employee

@Dao
interface EmployeeDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(employee: Employee): Long

    @Update
    suspend fun update(employee: Employee)

    @Delete
    suspend fun delete(employee: Employee)

    @Query("SELECT * FROM employees WHERE isActive = 1 ORDER BY name ASC")
    fun getAllActiveEmployees(): LiveData<List<Employee>>

    @Query("SELECT * FROM employees WHERE isActive = 1 ORDER BY name ASC")
    suspend fun getAllActiveEmployeesList(): List<Employee>

    @Query("SELECT * FROM employees WHERE id = :id")
    suspend fun getEmployeeById(id: Long): Employee?

    @Query("SELECT * FROM employees WHERE id = :id")
    fun getEmployeeByIdLive(id: Long): LiveData<Employee?>

    @Query("SELECT * FROM employees WHERE employeeCode = :code AND isActive = 1 LIMIT 1")
    suspend fun getEmployeeByCode(code: String): Employee?

    @Query("SELECT * FROM employees WHERE isAdmin = 1 LIMIT 1")
    suspend fun getAdmin(): Employee?

    @Query("SELECT COUNT(*) FROM employees WHERE isActive = 1 AND isAdmin = 0")
    fun getActiveEmployeeCount(): LiveData<Int>

    @Query("UPDATE employees SET isActive = 0 WHERE id = :id")
    suspend fun deactivateEmployee(id: Long)

    @Query("SELECT * FROM employees WHERE isActive = 1 AND isAdmin = 0 ORDER BY name ASC")
    fun getNonAdminEmployees(): LiveData<List<Employee>>
}
