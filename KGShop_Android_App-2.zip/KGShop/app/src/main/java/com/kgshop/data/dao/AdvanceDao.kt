package com.kgshop.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.kgshop.data.entities.Advance

@Dao
interface AdvanceDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(advance: Advance): Long

    @Update
    suspend fun update(advance: Advance)

    @Delete
    suspend fun delete(advance: Advance)

    @Query("SELECT * FROM advances WHERE employeeId = :employeeId ORDER BY date DESC")
    fun getAdvancesForEmployee(employeeId: Long): LiveData<List<Advance>>

    @Query("SELECT * FROM advances WHERE employeeId = :employeeId AND month = :month")
    suspend fun getAdvancesForMonth(employeeId: Long, month: String): List<Advance>

    @Query("SELECT SUM(amount) FROM advances WHERE employeeId = :employeeId AND month = :month")
    suspend fun getTotalAdvanceForMonth(employeeId: Long, month: String): Double?

    @Query("SELECT * FROM advances ORDER BY date DESC")
    fun getAllAdvances(): LiveData<List<Advance>>
}
