package com.kgshop.utils

import android.content.Context
import android.content.SharedPreferences

class SessionManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("KGShopSession", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_EMPLOYEE_ID = "employee_id"
        private const val KEY_IS_ADMIN = "is_admin"
        private const val KEY_NAME = "name"
        private const val KEY_LOGGED_IN = "is_logged_in"
    }

    fun saveSession(employeeId: Long, isAdmin: Boolean, name: String) {
        prefs.edit().apply {
            putLong(KEY_EMPLOYEE_ID, employeeId)
            putBoolean(KEY_IS_ADMIN, isAdmin)
            putString(KEY_NAME, name)
            putBoolean(KEY_LOGGED_IN, true)
            apply()
        }
    }

    fun isLoggedIn(): Boolean = prefs.getBoolean(KEY_LOGGED_IN, false)

    fun isAdmin(): Boolean = prefs.getBoolean(KEY_IS_ADMIN, false)

    fun getEmployeeId(): Long = prefs.getLong(KEY_EMPLOYEE_ID, -1L)

    fun getEmployeeName(): String = prefs.getString(KEY_NAME, "") ?: ""

    fun clearSession() {
        prefs.edit().clear().apply()
    }
}
