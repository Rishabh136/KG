package com.kgshop.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.kgshop.data.entities.Employee
import com.kgshop.data.repository.KGShopRepository
import kotlinx.coroutines.launch

class AuthViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = KGShopRepository(application)

    val loginResult = MutableLiveData<LoginResult>()

    fun login(code: String, password: String) {
        if (code.isBlank() || password.isBlank()) {
            loginResult.value = LoginResult.Error("Please enter Employee ID and password")
            return
        }
        viewModelScope.launch {
            val employee = repository.login(code.trim(), password.trim())
            if (employee != null) {
                loginResult.value = LoginResult.Success(employee)
            } else {
                loginResult.value = LoginResult.Error("Invalid credentials. Please try again.")
            }
        }
    }

    sealed class LoginResult {
        data class Success(val employee: Employee) : LoginResult()
        data class Error(val message: String) : LoginResult()
    }
}
